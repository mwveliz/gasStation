package net.bigpoint.assessment.gasstation;

public enum GasType {

	REGULAR,
	SUPER,
	DIESEL;

}
